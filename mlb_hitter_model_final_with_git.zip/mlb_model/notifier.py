
import requests

def send_discord_notification(top_picks_df, webhook_url):
    """Send top picks to Discord."""
    content = "**Today's MLB Top Picks:**\n"
    for _, row in top_picks_df.iterrows():
        content += f"- {row['Hitter']} → HR Score: {row['HR_Score']:.2f}, TB: {row['Expected_TB']:.2f}\n"
    payload = {"content": content}
    response = requests.post(webhook_url, json=payload)
    if response.status_code == 204:
        print("Discord notification sent.")
    else:
        print("Discord notification failed.")

def send_slack_notification(top_picks_df, webhook_url):
    """Send top picks to Slack."""
    content = "*Today's MLB Top Picks:*\n"
    for _, row in top_picks_df.iterrows():
        content += f"• {row['Hitter']} → HR Score: {row['HR_Score']:.2f}, TB: {row['Expected_TB']:.2f}\n"
    payload = {"text": content}
    response = requests.post(webhook_url, json=payload)
    if response.status_code == 200:
        print("Slack notification sent.")
    else:
        print("Slack notification failed.")
