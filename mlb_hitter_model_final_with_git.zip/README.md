
# MLB Hitter Model System

Automated MLB Daily Hitter Model with contextual adjustments.

## Features
- Scrapes lineups, pitcher stats, hitter splits
- Weather + Park Factors adjustments
- Google Sheet + Email report
- Slack & Discord notifications (optional)
- SQLite historical DB
- Manual run Jupyter Notebook
- Docker & Cron automation ready

## Notifications Integration
Optional: Receive Top Picks daily on Discord or Slack.

### Setup
1. Create Discord/Slack Webhook URL.
2. Add in `run_daily.py`:
```python
from mlb_model.notifier import send_discord_notification, send_slack_notification

send_discord_notification(top_picks_df, "YOUR_DISCORD_WEBHOOK_URL")
send_slack_notification(top_picks_df, "YOUR_SLACK_WEBHOOK_URL")
```

## Badges

![Python](https://img.shields.io/badge/Python-3.11-blue)
![License](https://img.shields.io/badge/License-MIT-green)
![Build](https://img.shields.io/badge/Build-Passing-brightgreen)
